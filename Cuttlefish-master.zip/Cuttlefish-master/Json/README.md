# http catcher code open source
> Provide for learning use  
> Share it with friends who need it

# 使用方法：打开网球->更多->重写->添加重写->文本编辑器中编辑->粘贴  
![使用方法](https://gitee.com/pm936/httpcatcher/raw/master/Addmethods.jpg)

