#### AD Block & Crack Configuration
