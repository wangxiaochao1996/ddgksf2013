{
  "rules" : [
    {
      "action" : "body",
      "matchField" : "",
      "field" : "",
      "value" : "Membership\":true",
      "matchValue" : "Membership\":false",
      "destiontion" : "response",
      "isRegex" : false
    }
  ],
  "enabled" : false,
  "isReadOnly" : false,
  "name" : "西窗烛",
  "locations" : [
    {
      "method" : "",
      "scheme" : "",
      "enabled" : true,
      "port" : 0,
      "query" : "",
      "host" : "avoscloud.com",
      "path" : ""
    }
  ],
  "description" : "微信公众号墨鱼手记，仅供学习交流使用"
}
