{
  "rules" : [
    {
      "action" : "body",
      "matchField" : "",
      "field" : "",
      "value" : "viptype\":\"4\"",
      "matchValue" : "viptype\":\"1\"",
      "destiontion" : "response",
      "isRegex" : false
    }
  ],
  "enabled" : false,
  "isReadOnly" : false,
  "name" : "一言",
  "locations" : [
    {
      "method" : "",
      "scheme" : "",
      "enabled" : true,
      "port" : 0,
      "query" : "",
      "host" : "115.28.168.103",
      "path" : ""
    }
  ],
  "description" : "微信公众号墨鱼手记，仅供学习交流使用"
}
